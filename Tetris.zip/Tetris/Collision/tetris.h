refines class Tetris
{
    bool collision(int x, int y,
                   int piece[4][4],
                   int rows, int cols)
    {
        for (int r = 0; r < rows; r++)
        {
            for (int c = 0; c < cols; c++)
            {
                if (piece[r][c] == 0)
                    continue;

                int newX = x + c;
                int newY = y + r;

                // Check board boundaries
                if (newX < 0 || newX >= WIDTH)
                    return true;

                if (newY >= HEIGHT)
                    return true;

                // Check occupied cells
                if (newY >= 0 &&
                    board[newY][newX] != 0)
                    return true;
            }
        }

        return false;
    }

    void moveDown()
    {
        if (!collision(x, y + 1, currentPiece,
                       pieceRows, pieceCols))
        {
            y++;
        }
        else
        {
            lockPiece();
        }
    }
};