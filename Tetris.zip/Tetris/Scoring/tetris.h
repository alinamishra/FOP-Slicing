class Scoring {
protected:
    int score;

public:
    void updateScore(int clearedLines) {
        score += clearedLines * 100;
    }

    int getScore() {
        return score;
    }
};