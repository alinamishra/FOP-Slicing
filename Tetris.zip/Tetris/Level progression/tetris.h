class LevelProgression {
protected:
    int level;
    int totalLines;

public:
    LevelProgression() : level(1), totalLines(0) {}

    void updateLevel(int clearedLines) {
        totalLines += clearedLines;
        level = 1 + totalLines / 10;
    }

    int getLevel() {
        return level;
    }
};