#include <iostream>
using namespace std;

class Tetris {
protected:
    int x, y;
    int score;
    int level;
    bool gameOver;

public:
    Tetris() {
        x = 5;
        y = 0;
        score = 0;
        level = 1;
        gameOver = false;
    }

    void moveLeft() {
        if (!gameOver)
            x--;
    }

    void moveRight() {
        if (!gameOver)
            x++;
    }

    void drop() {
        if (!gameOver)
            y++;
    }

    void rotateLeft() {
        cout << "Rotate piece left\n";
    }

    void rotateRight() {
        cout << "Rotate piece right\n";
    }

    void checkCollision() {
        if (x < 0 || x >= 10 || y >= 20)
            gameOver = true;
    }

    void display() {
        cout << "Position: (" << x << ", " << y << ")\n";
        cout << "Game Over: " << gameOver << '\n';
    }
};

int main() {
    Tetris game;
    game.moveRight();
    game.drop();
    game.checkCollision();
    game.display();
    return 0;
}