#include<stdio.h>
class factorial
{
public:
	int n,r;
	int enter()
{
printf("\n enter two number:");
		scanf("%d %d",&n,&r);
}
	int calc()
{
    
if (n >= 0 && r>=0)
        printf("\n n and r positive number");
else if(n>=0 && r<0)
	printf("\n n is positive and r negative number");
else if(n<0 && r>=0)
	printf("\n n is negative and r positive number");
else
        printf("\r n and r are negative number");
return 0;
}
	 
};
int main()
{
	factorial c1;
	c1.enter();
	c1.calc();
	return 0;
}


  
  
