refines class factorial
{
public:
	int calc()
	{
	
		int i,fact=1,j,fac;  
		int res = super::calc();

if(n<=0)
{
printf("\n factorial not exist"); }
else if(n>=0)
  {   
  for(i=1;i<=n;i++) { 
fact=fact*i; 
}    
printf("\n factorial of %d is %d",n,fact);}
if(r>=0){
	for(j=1;j<=r;j++)
	{
	fac=fac*j; }
printf("\n factorial of %d is %d",r,fac);
 } 
else{
	printf("\n factorial not exist");}
 


    return 0;
 }   
		

};



  
  
