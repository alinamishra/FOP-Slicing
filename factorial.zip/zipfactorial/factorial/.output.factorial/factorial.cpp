#include "factorial.h"

#line 25 "C:/Users/hpriya/Downloads/zipfactorial/factorial/Base/factorial.h"

int main()
{
	factorial c1;
	c1.enter();
	c1.calc();
	return 0;
}


  
  

