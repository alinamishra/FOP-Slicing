#ifndef factorial_h__included
#define factorial_h__included

//Layer Base


#line 1 "C:/Users/hpriya/Downloads/zipfactorial/factorial/Base/factorial.h"
#include<stdio.h>

//Layer factorial


//Layer permutation



#line 2 "C:/Users/hpriya/Downloads/zipfactorial/factorial/Base/factorial.h"
class factorial
{
//**** Layer Base ****
#line 3 "C:/Users/hpriya/Downloads/zipfactorial/factorial/Base/factorial.h"

public:
	int n,r;
	int enter()
{
printf("\n enter two number:");
		scanf("%d %d",&n,&r);
}
	__forceinline 
#line 11 "C:/Users/hpriya/Downloads/zipfactorial/factorial/Base/factorial.h"
int Base_calc()
{
    
if (n >= 0 && r>=0)
        printf("\n n and r positive number");
else if(n>=0 && r<0)
	printf("\n n is positive and r negative number");
else if(n<0 && r>=0)
	printf("\n n is negative and r positive number");
else
        printf("\r n and r are negative number");
return 0;
}
	 

//**** Layer factorial ****
#line 2 "C:/Users/hpriya/Downloads/zipfactorial/factorial/factorial/factorial.h"

public:
	__forceinline 
#line 4 "C:/Users/hpriya/Downloads/zipfactorial/factorial/factorial/factorial.h"
int factorial_calc()
	{
	
		int i,fact=1,j,fac;  
		int res = Base_calc();

if(n<=0)
{
printf("\n factorial not exist"); }
else if(n>=0)
  {   
  for(i=1;i<=n;i++) { 
fact=fact*i; 
}    
printf("\n factorial of %d is %d",n,fact);}
if(r>=0){
	for(j=1;j<=r;j++)
	{
	fac=fac*j; }
printf("\n factorial of %d is %d",r,fac);
 } 
else{
	printf("\n factorial not exist");}
 


    return 0;
 }   
		


//**** Layer permutation ****
#line 2 "C:/Users/hpriya/Downloads/zipfactorial/factorial/permutation/factorial.h"

	int calc()
	{
		int per, fact, fact2,number,i; 
		int res = factorial_calc();
    		fact = n;     
    		number = n - r;  
    		fact = number;  
    		for (i = number - 1; i >= 1; i--)  
    		{  
        		fact2 = fact2 * i;  
    		}  
    		per = fact1 / fact2;  
   		printf("\n nPr = %d",per);  
		return 0;
	}

#line 25 "C:/Users/hpriya/Downloads/zipfactorial/factorial/Base/factorial.h"
};
#endif //factorial_h__included

