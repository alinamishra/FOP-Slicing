public refines class factorial
{
	int calc()
	{
		int per, fact, fact2,number,i; 
		int res = super::calc();
    		fact = n;     
    		number = n - r;  
    		fact = number;  
    		for (i = number - 1; i >= 1; i--)  
    		{  
        		fact2 = fact2 * i;  
    		}  
    		per = fact1 / fact2;  
   		printf("\n nPr = %d",per);  
		return 0;
	}
};

    
