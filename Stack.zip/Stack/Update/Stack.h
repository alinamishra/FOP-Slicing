
refines class Stack {
private:
    int stackSize = 0;

public:
    void Push(int value) {
        Super::Push(value);
        stackSize++;
    }

    void Pop() {
        if (stackSize > 0) {
            Super::Pop();
            stackSize--;
        } else {
            Super::Pop();
        }
    }

    void Display() {
        cout << "Stack size: " << stackSize << '\n';
    }
};

#endif