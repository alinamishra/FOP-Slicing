
refines class Stack {
protected:
    bool blocked = false;

public:
    void Block() {
        blocked = true;
        cout << "Stack operations blocked\n";
    }

    void Push(int value) {
        if (blocked) {
            cout << "Push rejected: stack blocked\n";
            return;
        }
        Super::Push(value);
    }

    void Pop() {
        if (blocked) {
            cout << "Pop rejected: stack blocked\n";
            return;
        }
        Super::Pop();
    }
};
