
refines class Stack {
public:
    void Unblock() {
        blocked = false;
        cout << "Stack operations unblocked\n";
    }
};
