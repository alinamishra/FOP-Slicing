#ifndef STACK_H
#define STACK_H

#include <iostream>
#include <vector>
using namespace std;

class Stack {
protected:
    vector<int> elements;

public:
    void Push(int value) {
        elements.push_back(value);
    }

    void Pop() {
        if (elements.empty()) {
            cout << "Stack is empty\n";
            return;
        }

        cout << "Popped: " << elements.back() << '\n';
        elements.pop_back();
    }

    void Display() {
        cout << "Stack size: " << elements.size() << '\n';
    }
};

#endif