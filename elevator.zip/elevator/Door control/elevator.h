refines class Elevator
{
    void openDoor()
    {
        doorOpen = true;
        cout << "Door opened" << endl;
    }

    void closeDoor()
    {
        doorOpen = false;
        cout << "Door closed" << endl;
    }
};