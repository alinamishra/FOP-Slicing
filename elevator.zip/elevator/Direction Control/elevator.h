refines class Elevator
{
    void determineDirection()
    {
        if (requestedFloor > currentFloor)
            direction = 1;
        else if (requestedFloor < currentFloor)
            direction = -1;
        else
            direction = 0;
    }
};