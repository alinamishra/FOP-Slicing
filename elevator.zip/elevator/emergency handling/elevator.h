refines class Elevator
{
    bool emergency;

    void triggerEmergency()
    {
        emergency = true;
        direction = 0;

        cout << "ALARM: Elevator stopped!"
             << endl;
    }
};