class Elevator
{
protected:
    int currentFloor;
    int requestedFloor;
    int direction;
    bool doorOpen;

public:
    Elevator()
    {
        currentFloor = 0;
        requestedFloor = 0;
        direction = 0;
        doorOpen = false;
    }

    void requestFloor(int floor)
    {
        requestedFloor = floor;
    }
};