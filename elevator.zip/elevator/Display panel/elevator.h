refines class Elevator
{
    void displayFloor()
    {
        cout << "Current floor: "
             << currentFloor << endl;
    }
};