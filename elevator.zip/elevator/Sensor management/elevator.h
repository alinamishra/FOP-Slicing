refines class Elevator
{
    bool obstacleDetected;

    void checkSensor()
    {
        if (obstacleDetected)
        {
            doorOpen = true;
            cout << "Obstacle detected. "
                 << "Door remains open." << endl;
        }
    }
};