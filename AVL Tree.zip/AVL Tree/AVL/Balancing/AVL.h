refines class AVLTree {
public:
    int height(Node* n) {
        return n == 0 ? 0 : n->height;
    }

    int getBalance(Node* n) {
        return n == 0 ? 0 :
            height(n->left) - height(n->right);
    }

    void updateHeight(Node* n) {
        if (n != 0)
            n->height = 1 +
                max(height(n->left), height(n->right));
    }
};