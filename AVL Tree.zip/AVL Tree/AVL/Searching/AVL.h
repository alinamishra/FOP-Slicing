
refines class AVLTree {
public:
    bool search(Node* node, int key) {
        if (node == 0)
            return false;

        if (node->key == key)
            return true;

        if (key < node->key)
            return search(node->left, key);

        return search(node->right, key);
    }

    bool searchKey(int key) {
        return search(root, key);
    }
};
