class AVLTree {
public:
    struct Node {
        int key;
        int height;
        Node* left;
        Node* right;

        Node(int k) {
            key = k;
            height = 1;
            left = right = 0;
        }
    };

    Node* root;

    AVLTree() {
        root = 0;
    }
};