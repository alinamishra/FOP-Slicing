
refines class AVLTree {
public:
    void inorder(Node* node) {
        if (node != 0) {
            inorder(node->left);
            cout << node->key << " ";
            inorder(node->right);
        }
    }

    void display() {
        inorder(root);
        cout << endl;
    }
};
